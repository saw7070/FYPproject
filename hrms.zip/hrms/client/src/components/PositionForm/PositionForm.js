import React from 'react';

const PositionForm = () => {
  return <div></div>;
};

export default PositionForm;
