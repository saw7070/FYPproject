import React from 'react';

const PositionHome = () => {
  return <div></div>;
};

export default PositionHome;
